function [x] = Sherman_Morrison_Woodbury(tL, tU, P, Q, U, V, yy)
% Given a sparse LU decomposition of matrix M
% [tL, tU, P, Q]=lu(M);
% U (n by p) and V (p by n) are the rank-p update matrices
% such that M_hat = (M + UV), a rank-p perturbation of M 
% Use Sherman-Morrison-Woodbury to find 
% x=(M + PV)^{-1} b
% For efficiency purposes, we may make
%   yy a global vector (but not here): global yy I_p
%  
% M^{-1} yy = b,  yy = Q*(tU\(tL\(P*b)))
% has been precomputed once and used many times.
% 
% This function returns x=(M+UV)^{-1}*b
%
% To improve efficiency, p no longer
% generated within the function. I_(pxp) is
% a global variable.
[n,p]=size(U);
%%% yy=Q*(tU\(tL\(P*b)));
%
W=Q*(tU\(tL\(P*U)));
%
%
%C=I_p+V*W;
%
C=speye(p)+V*W;
%
z=C\(V*yy);
x=yy-W*z;
end

